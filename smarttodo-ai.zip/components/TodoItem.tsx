
import React, { useState } from 'react';
import { Todo, SubTask } from '../types';
import { breakdownTask } from '../services/geminiService';

interface Props {
  todo: Todo;
  onToggle: () => void;
  onDelete: () => void;
  onUpdate: (todo: Todo) => void;
}

const TodoItem: React.FC<Props> = ({ todo, onToggle, onDelete, onUpdate }) => {
  const [isBreakingDown, setIsBreakingDown] = useState(false);

  const handleBreakdown = async () => {
    setIsBreakingDown(true);
    const subtasksText = await breakdownTask(todo.text);
    const newSubTasks: SubTask[] = subtasksText.map(text => ({
      id: crypto.randomUUID(),
      text,
      completed: false
    }));
    onUpdate({ ...todo, subTasks: [...(todo.subTasks || []), ...newSubTasks] });
    setIsBreakingDown(false);
  };

  const toggleSubTask = (subId: string) => {
    const updatedSubTasks = (todo.subTasks || []).map(st => 
      st.id === subId ? { ...st, completed: !st.completed } : st
    );
    onUpdate({ ...todo, subTasks: updatedSubTasks });
  };

  const priorityColor = {
    high: 'bg-rose-500',
    medium: 'bg-amber-500',
    low: 'bg-emerald-500'
  }[todo.priority];

  const completedSubTasks = (todo.subTasks || []).filter(st => st.completed).length;
  const totalSubTasks = (todo.subTasks || []).length;
  const progress = totalSubTasks > 0 ? (completedSubTasks / totalSubTasks) * 100 : 0;

  return (
    <div className={`group bg-white rounded-2xl border border-slate-200 p-4 transition-all hover:shadow-md ${todo.completed ? 'opacity-60' : ''}`}>
      <div className="flex items-start gap-4">
        <button 
          onClick={onToggle}
          className={`mt-1 flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${todo.completed ? 'bg-indigo-600 border-indigo-600 text-white' : 'border-slate-300 text-transparent hover:border-indigo-400'}`}
        >
          <i className="fa-solid fa-check text-xs"></i>
        </button>
        
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className={`w-2 h-2 rounded-full ${priorityColor}`}></span>
            <h3 className={`text-lg font-medium text-slate-800 ${todo.completed ? 'line-through' : ''}`}>
              {todo.text}
            </h3>
          </div>
          
          <div className="flex items-center gap-3 text-xs text-slate-400">
            <span>{new Date(todo.createdAt).toLocaleDateString()}</span>
            {totalSubTasks > 0 && (
              <span className="flex items-center gap-1 text-indigo-500 font-semibold">
                <i className="fa-solid fa-diagram-project"></i> {completedSubTasks}/{totalSubTasks} steps
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <button 
            onClick={handleBreakdown}
            disabled={isBreakingDown || todo.completed}
            className="p-2 text-indigo-500 hover:bg-indigo-50 rounded-lg disabled:opacity-30"
            title="AI Breakdown"
          >
            {isBreakingDown ? (
              <i className="fa-solid fa-spinner fa-spin"></i>
            ) : (
              <i className="fa-solid fa-wand-sparkles"></i>
            )}
          </button>
          <button 
            onClick={onDelete}
            className="p-2 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg"
          >
            <i className="fa-solid fa-trash-can"></i>
          </button>
        </div>
      </div>

      {totalSubTasks > 0 && (
        <div className="mt-4 pt-4 border-t border-slate-50">
          <div className="h-1.5 w-full bg-slate-100 rounded-full mb-4 overflow-hidden">
            <div 
              className="h-full bg-indigo-500 transition-all duration-500" 
              style={{ width: `${progress}%` }}
            ></div>
          </div>
          
          <div className="space-y-2 ml-10">
            {(todo.subTasks || []).map((st) => (
              <div 
                key={st.id} 
                onClick={() => toggleSubTask(st.id)}
                className="flex items-center gap-3 cursor-pointer group/sub"
              >
                <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${st.completed ? 'bg-indigo-400 border-indigo-400 text-white' : 'border-slate-300 text-transparent group-hover/sub:border-indigo-300'}`}>
                  <i className="fa-solid fa-check text-[10px]"></i>
                </div>
                <span className={`text-sm text-slate-600 ${st.completed ? 'line-through opacity-50' : ''}`}>
                  {st.text}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default TodoItem;
