
import React, { useState } from 'react';
import { Priority } from '../types';

interface Props {
  onAdd: (text: string, priority: Priority) => void;
}

const TodoInput: React.FC<Props> = ({ onAdd }) => {
  const [text, setText] = useState('');
  const [priority, setPriority] = useState<Priority>('medium');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim()) {
      onAdd(text.trim(), priority);
      setText('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex flex-col gap-4">
      <input
        type="text"
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Add a new task..."
        className="text-lg font-medium text-slate-800 placeholder:text-slate-300 border-none focus:ring-0 w-full"
      />
      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          {(['low', 'medium', 'high'] as Priority[]).map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => setPriority(p)}
              className={`px-3 py-1 rounded-full text-xs font-semibold capitalize transition-all ${
                priority === p 
                  ? (p === 'high' ? 'bg-rose-100 text-rose-600' : p === 'medium' ? 'bg-amber-100 text-amber-600' : 'bg-emerald-100 text-emerald-600')
                  : 'bg-slate-50 text-slate-400 hover:bg-slate-100'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
        <button
          type="submit"
          disabled={!text.trim()}
          className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white px-4 py-2 rounded-xl text-sm font-bold transition-all flex items-center gap-2"
        >
          <i className="fa-solid fa-plus"></i> Add Task
        </button>
      </div>
    </form>
  );
};

export default TodoInput;
