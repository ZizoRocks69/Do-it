
export interface SubTask {
  id: string;
  text: string;
  completed: boolean;
}

export interface Todo {
  id: string;
  text: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  createdAt: number;
  subTasks?: SubTask[];
}

export type Priority = 'low' | 'medium' | 'high';
