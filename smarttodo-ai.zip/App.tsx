
import React, { useState, useEffect } from 'react';
import { Todo, Priority } from './types';
import TodoInput from './components/TodoInput';
import TodoItem from './components/TodoItem';

const App: React.FC = () => {
  const [todos, setTodos] = useState<Todo[]>(() => {
    const saved = localStorage.getItem('smart-todos');
    return saved ? JSON.parse(saved) : [];
  });
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all');

  useEffect(() => {
    localStorage.setItem('smart-todos', JSON.stringify(todos));
  }, [todos]);

  const addTodo = (text: string, priority: Priority) => {
    const newTodo: Todo = {
      id: crypto.randomUUID(),
      text,
      completed: false,
      priority,
      createdAt: Date.now(),
      subTasks: []
    };
    setTodos([newTodo, ...todos]);
  };

  const toggleTodo = (id: string) => {
    setTodos(todos.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const deleteTodo = (id: string) => {
    setTodos(todos.filter(t => t.id !== id));
  };

  const updateTodo = (updated: Todo) => {
    setTodos(todos.map(t => t.id === updated.id ? updated : t));
  };

  const clearCompleted = () => {
    setTodos(todos.filter(t => !t.completed));
  };

  const filteredTodos = todos.filter(t => {
    if (filter === 'active') return !t.completed;
    if (filter === 'completed') return t.completed;
    return true;
  });

  const completedCount = todos.filter(t => t.completed).length;

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#f9fafb]">
      {/* Sidebar */}
      <aside className="w-full md:w-72 bg-white border-r border-slate-200 p-8 flex flex-col gap-8">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-indigo-600 w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-100">
              <i className="fa-solid fa-list-check text-lg"></i>
            </div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">SmartTodo AI</h1>
          </div>
          <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">Productivity Engine</p>
        </div>

        <nav className="flex flex-col gap-2">
          <button 
            onClick={() => setFilter('all')}
            className={`flex items-center justify-between px-4 py-3 rounded-xl text-sm font-semibold transition-all ${filter === 'all' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'}`}
          >
            <span className="flex items-center gap-3"><i className="fa-solid fa-layer-group w-5"></i> All Tasks</span>
            <span className="bg-slate-100 px-2 py-0.5 rounded-md text-[10px]">{todos.length}</span>
          </button>
          <button 
            onClick={() => setFilter('active')}
            className={`flex items-center justify-between px-4 py-3 rounded-xl text-sm font-semibold transition-all ${filter === 'active' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'}`}
          >
            <span className="flex items-center gap-3"><i className="fa-solid fa-bolt-lightning w-5"></i> Active</span>
            <span className="bg-slate-100 px-2 py-0.5 rounded-md text-[10px]">{todos.filter(t => !t.completed).length}</span>
          </button>
          <button 
            onClick={() => setFilter('completed')}
            className={`flex items-center justify-between px-4 py-3 rounded-xl text-sm font-semibold transition-all ${filter === 'completed' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'}`}
          >
            <span className="flex items-center gap-3"><i className="fa-solid fa-circle-check w-5"></i> Completed</span>
            <span className="bg-slate-100 px-2 py-0.5 rounded-md text-[10px]">{completedCount}</span>
          </button>
        </nav>

        {completedCount > 0 && (
          <button 
            onClick={clearCompleted}
            className="mt-2 text-left px-4 py-2 text-xs font-bold text-rose-500 hover:text-rose-600 transition-colors flex items-center gap-2"
          >
            <i className="fa-solid fa-trash-sweep"></i> Clear Completed
          </button>
        )}

        <div className="mt-auto">
          <div className="bg-gradient-to-br from-indigo-600 to-violet-700 rounded-2xl p-5 text-white shadow-xl shadow-indigo-100">
            <div className="flex items-center gap-2 mb-3">
              <i className="fa-solid fa-wand-magic-sparkles"></i>
              <h3 className="text-sm font-bold">Smart Tips</h3>
            </div>
            <p className="text-xs leading-relaxed opacity-90">
              Try adding a complex goal like "Plan a 3-day trip to Tokyo" and hit the breakdown button!
            </p>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 md:p-12 lg:p-16 overflow-y-auto">
        <div className="max-w-3xl mx-auto">
          <header className="mb-10">
            <h2 className="text-3xl font-black text-slate-800 tracking-tight">
              {filter === 'all' ? "Today's Focus" : filter.charAt(0).toUpperCase() + filter.slice(1) + " Tasks"}
            </h2>
            <p className="text-slate-500 mt-2 font-medium">Capture your ideas and let AI help you execute them.</p>
          </header>

          <TodoInput onAdd={addTodo} />

          <div className="mt-10 space-y-4">
            {filteredTodos.length === 0 ? (
              <div className="text-center py-20 bg-white border-2 border-dashed border-slate-200 rounded-[2rem] flex flex-col items-center">
                <div className="bg-slate-50 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                  <i className="fa-solid fa-mug-hot text-slate-300 text-2xl"></i>
                </div>
                <p className="text-slate-400 font-medium">Nothing to do here yet.</p>
                <p className="text-slate-300 text-sm">Add a task to get started.</p>
              </div>
            ) : (
              filteredTodos.map(todo => (
                <TodoItem 
                  key={todo.id} 
                  todo={todo} 
                  onToggle={() => toggleTodo(todo.id)}
                  onDelete={() => deleteTodo(todo.id)}
                  onUpdate={updateTodo}
                />
              ))
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
