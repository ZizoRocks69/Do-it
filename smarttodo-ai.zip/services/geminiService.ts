
import { GoogleGenAI, Type } from "@google/genai";
import { SubTask } from "../types";

export const breakdownTask = async (taskText: string): Promise<string[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are a productivity expert. Break down the following task into exactly 4-6 highly actionable, bite-sized steps that a user can check off sequentially. 
      Task: "${taskText}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            subtasks: {
              type: Type.ARRAY,
              items: { 
                type: Type.STRING,
                description: "A short, actionable instruction starting with a verb."
              }
            }
          },
          required: ["subtasks"]
        }
      },
    });

    const text = response.text;
    if (!text) return [];
    
    const result = JSON.parse(text);
    return result.subtasks || [];
  } catch (error) {
    console.error("AI Breakdown failed:", error);
    return [];
  }
};
